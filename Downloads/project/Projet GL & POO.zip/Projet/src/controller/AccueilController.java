package controller;

import javafx.application.Application;
import javafx.stage.Stage;

public class AccueilController extends Application {

	@Override
	public void start(Stage arg0) throws Exception {
		
		
	}

}
